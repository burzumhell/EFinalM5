/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Cliente
 */
package cl.bubbles.finalspring.services;

import cl.bubbles.finalspring.entity.Cliente;

public interface IClienteService {

	public Cliente readOne(int id);
	public void crearCliente(Cliente c);
	public void update(Cliente c);
	
}
