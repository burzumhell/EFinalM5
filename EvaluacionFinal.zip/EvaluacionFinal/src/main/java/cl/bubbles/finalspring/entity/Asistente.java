/**
 * @author The Bubbles
 * Clase de objeto Asistente
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ASISTENTE")
public class Asistente {

	@Id
	@Column(name = "idasistente")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "asistente_seq")
	@SequenceGenerator(name = "asistente_seq", allocationSize = 1)
	private int id;
	
	@Column(name = "asisnombre")
	private String nombre;
	
	@Column(name = "asisedad")
	private int edad;
	
	@Column(name = "asiscorreo")
	private String correo;
	
	@Column(name = "asistelefono")
	private String telefono;
	
	@ManyToOne
	@JoinColumn(name = "capacitacion_idcapacitacion")
	private Capacitacion capacitacion;
	
	/**
	 * Constructor vacío
	 */
	public Asistente() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param id
	 * @param nombre
	 * @param edad
	 * @param correo
	 * @param telefono
	 * @param capacitacion
	 */
	public Asistente(int id, String nombre, int edad, String correo, String telefono, Capacitacion capacitacion) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
		this.correo = correo;
		this.telefono = telefono;
		this.capacitacion = capacitacion;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Capacitacion getCapacitacion() {
		return capacitacion;
	}

	public void setCapacitacion(Capacitacion capacitacion) {
		this.capacitacion = capacitacion;
	}

	@Override
	public String toString() {
		return "Asistente [id=" + id + ", nombre=" + nombre + ", edad=" + edad + ", correo=" + correo + ", telefono="
				+ telefono + ", capacitacion=" + capacitacion + "]";
	}
}