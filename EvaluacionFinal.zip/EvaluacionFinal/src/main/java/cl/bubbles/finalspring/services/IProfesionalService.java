/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Profesional
 */
package cl.bubbles.finalspring.services;

import cl.bubbles.finalspring.entity.Profesional;

public interface IProfesionalService {

	public Profesional readOne(int id);
	public void crearProfesional(Profesional p);
	public void update(Profesional a);
	
}
