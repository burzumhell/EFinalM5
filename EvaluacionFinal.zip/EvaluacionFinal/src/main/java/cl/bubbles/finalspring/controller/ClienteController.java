/**
 * @author The Bubbles
 * Controlador para la clase Cliente
 */
package cl.bubbles.finalspring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Cliente;
import cl.bubbles.finalspring.services.ClienteServiceImpl;

@Controller
public class ClienteController {

	@Autowired
	private ClienteServiceImpl cs;
	
	/**
	 * Método para acceder al formulario de registro de un usuario tipo Cliente
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_cliente", method = RequestMethod.GET)
	public String crearCliente() {
		
		return "crear_cliente";
		
	}
	
	/**
	 * Método que recibe los datos del cliente y crea un nuevo registro
	 * @param c objeto Cliente
	 * @return vista de listado de usuarios
	 */
	@RequestMapping(value = "/crear_cliente", method = RequestMethod.POST)
	public ModelAndView crearCliente(Cliente c) {
		
		cs.crearCliente(c);
		
		return new ModelAndView("redirect:/listar_usuarios");
		
	}
	
	/**
	 * Método para edición de usuario tipo Cliente
	 * @param c objeto Cliente
	 * @return vista de listado de usuarios
	 */
	@RequestMapping(value = "/editar_cliente", method = RequestMethod.POST)
	public ModelAndView editarUsuario(Cliente c) {
		
		cs.update(c);
		
		return new ModelAndView("redirect:/listar_usuarios");
	}
}
