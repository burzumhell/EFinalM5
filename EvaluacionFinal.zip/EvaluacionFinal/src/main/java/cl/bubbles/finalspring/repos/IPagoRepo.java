/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Pago
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.bubbles.finalspring.entity.Pago;

@Repository
public interface IPagoRepo extends JpaRepository<Pago, Integer> {

}
