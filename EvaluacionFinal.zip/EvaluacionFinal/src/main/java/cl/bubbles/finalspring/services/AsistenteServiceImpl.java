/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Asistente
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Asistente;
import cl.bubbles.finalspring.repos.IAsistenteRepo;

@Service
public class AsistenteServiceImpl implements IAsistenteService {

	@Autowired
	IAsistenteRepo ar;
	
	@Override
	public List<Asistente> listarAsistentes() {
		
		return ar.findAll();
	}

	@Override
	public void agregarAsistente(Asistente a) {
		
		ar.save(a);
	}

	@Override
	public void eliminarAsistente(int id) {
		// TODO Auto-generated method stub
		ar.deleteById(id);
	}
}
