/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un mensaje de contacto
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			nombre: {
				required: true,
				rangelength: [3, 20]
			},
            correo: {
                required: true,
                email: true
            },
			telefono: {
                required: true,
                digits: true,
                minlength: 9,
                maxlength: 9
            },
            mensaje: {
				required: true,
				rangelength: [10, 250]
			}
        }
    });
});