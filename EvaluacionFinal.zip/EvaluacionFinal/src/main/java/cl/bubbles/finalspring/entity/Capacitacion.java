/**
 * @author The Bubbles
 * Clase de objeto Capacitación
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CAPACITACION")
public class Capacitacion {
	
	@Id 
	@Column(name = "idcapacitacion")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "capacitacion_seq")
	@SequenceGenerator(name = "capacitacion_seq", allocationSize = 1)
	private int id;
	
	@Column(name = "caprut_cliente")
	private String rutCliente;
	
	@Column(name = "capdia")
	private String dia;
	
	@Column(name = "caphora")
	private String hora;
	
	@Column(name = "caplugar")
	private String lugar;
	
	@Column(name = "capduracion")
	private int duracion;
	
	@Column(name = "capasistentes")
	private int asistentes;

	@ManyToOne
	@JoinColumn(name = "cliente_idcliente")
	private Cliente cliente;
	
	/**
	 * Constructor vacío
	 */
	public Capacitacion() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param id
	 * @param rutCliente
	 * @param dia
	 * @param hora
	 * @param lugar
	 * @param duracion
	 * @param asistentes
	 * @param cliente
	 */
	public Capacitacion(int id, String rutCliente, String dia, String hora, String lugar, int duracion, int asistentes,
			Cliente cliente) {
		super();
		this.id = id;
		this.rutCliente = rutCliente;
		this.dia = dia;
		this.hora = hora;
		this.lugar = lugar;
		this.duracion = duracion;
		this.asistentes = asistentes;
		this.cliente = cliente;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRutCliente() {
		return rutCliente;
	}

	public void setRutCliente(String rutCliente) {
		this.rutCliente = rutCliente;
	}

	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public int getAsistentes() {
		return asistentes;
	}

	public void setAsistentes(int asistentes) {
		this.asistentes = asistentes;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	@Override
	public String toString() {
		return "Capacitacion [id=" + id + ", rutCliente=" + rutCliente + ", dia=" + dia + ", hora=" + hora + ", lugar="
				+ lugar + ", duracion=" + duracion + ", asistentes=" + asistentes + ", cliente=" + cliente + "]";
	}
}
