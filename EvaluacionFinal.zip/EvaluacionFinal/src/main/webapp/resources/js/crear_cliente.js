/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un cliente
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			rut: {
                required: true,
                rangelength: [11, 12]
            },
            razonSocial: {
                required: true,
                rangelength: [5, 30]
            },
			direccion: {
                required: true,
                rangelength: [7, 50]
            },
			comuna: {
                required: true,
                rangelength: [5, 20]
            },
            cantEmpleados: {
                required: true,
                min: 5,
                max: 999
            },
            telefono: {
                required: true,
                digits: true,
                minlength: 9,
                maxlength: 9
            },
        }
    });
});