/**
 * @author The Bubbles
 * Clase de objeto Cliente
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PAGO")
public class Pago {

	@Id
	@Column(name = "idpago")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pago_seq")
	@SequenceGenerator(name = "pago_seq", allocationSize = 1)
	private int idPago;
	
	@Column(name = "pagofecha")
	private String fecha;
	
	@Column(name = "pagomonto")
	private int monto;
	
	@Column(name = "pagomes")
	private String mes;
	
	@Column(name = "pagoanio")
	private String anio;
	
	@Column(name = "cliente")
	private String nombreCliente;

	@ManyToOne
	@JoinColumn(name = "cliente_idcliente")
	private Cliente cliente;
	
	/**
	 * Constructor vacío
	 */
	public Pago() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param idPago
	 * @param fecha
	 * @param monto
	 * @param mes
	 * @param anio
	 * @param nombreCliente
	 * @param cliente
	 */
	public Pago(int idPago, String fecha, int monto, String mes, String anio,
			String nombreCliente, Cliente cliente) {
		super();
		this.idPago = idPago;
		this.fecha = fecha;
		this.monto = monto;
		this.mes = mes;
		this.anio = anio;
		this.nombreCliente = nombreCliente;
		this.cliente = cliente;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdPago() {
		return idPago;
	}

	public void setIdPago(int idPago) {
		this.idPago = idPago;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getMonto() {
		return monto;
	}

	public void setMonto(int monto) {
		this.monto = monto;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public String getAnio() {
		return anio;
	}

	public void setAnio(String anio) {
		this.anio = anio;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	@Override
	public String toString() {
		return "Pago [idPago=" + idPago + ", fecha=" + fecha + ", monto=" + monto + ", mes=" + mes + ", anio=" + anio
				+ ", nombreCliente=" + nombreCliente + ", cliente=" + cliente + "]";
	}
}
