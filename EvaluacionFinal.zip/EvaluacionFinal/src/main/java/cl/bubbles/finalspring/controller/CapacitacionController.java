/**
 * @author The Bubbles
 * Controlador para la clase Capacitacion
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Capacitacion;
import cl.bubbles.finalspring.services.CapacitacionServiceImpl;

@Controller
public class CapacitacionController {

	@Autowired
	private CapacitacionServiceImpl cs;
	
	/**
	 * Método para obtener listado de capacitaciones
	 * @return listado de capacitaciones
	 */
	@RequestMapping(value = "/listar_capacitaciones", method = RequestMethod.GET)
	public ModelAndView listarCapacitaciones() {
		
		List<Capacitacion> lista = cs.listarCapacitaciones();
		
		ModelAndView mv = new ModelAndView("listar_capacitaciones");
		mv.addObject("lista", lista);
		
		return mv;
	}
	
	/**
	 * Método para acceder al formulario de registro de una capacitación
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_capacitacion", method = RequestMethod.GET)
	public String crearCapacitacion() {
		
		return "crear_capacitacion";
	}
	
	/**
	 * Método que recibe los datos de una capacitación y crea un nuevo registro
	 * @param c objeto Capacitacion
	 * @return vista de listado de capacitaciones
	 */
	@RequestMapping(value = "/crear_capacitacion", method = RequestMethod.POST)
	public ModelAndView crearCapacitacion(Capacitacion c) {
		
		cs.crearCapacitacion(c);
		
		return new ModelAndView("redirect:/listar_capacitaciones");
	}
	
	/**
	 * Método para eliminar un registro de capacitacion
	 * @param id de la capacitacion
	 * @return vista de listado de capacitaciones
	 */
	@RequestMapping(value = "eliminar_capacitacion/{id}", method = RequestMethod.GET)
	public ModelAndView eliminarCapacitacion(@PathVariable("id") int id) {
		
		cs.eliminarCapacitacion(id);
		
		return new ModelAndView("redirect:/listar_capacitaciones");
	}
}
