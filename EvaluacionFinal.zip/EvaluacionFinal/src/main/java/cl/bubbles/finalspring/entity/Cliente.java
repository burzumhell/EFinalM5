/**
 * @author The Bubbles
 * Clase de objeto Cliente
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CLIENTE")
public class Cliente {
	
	@Id
	@Column(name = "idcliente")
	private int idCliente;
	
	@Column(name="rut_cliente")
	private String rut;
	
	@Column(name = "clirazon_social")
	private String razonSocial;
	
	@Column(name= "clidireccion")
	private String direccion;
	
	@Column(name = "clicomuna")
	private String comuna;
	
	@Column(name = "cliempleados")
	private int cantEmpleados;
	
	@Column(name="clitelefono")
	private String telefono;
	
	@ManyToOne
	@JoinColumn(name = "usuario_idusuario")
	private Usuario usuario;
	
	/**
	 * Constructor vacío
	 */
	public Cliente() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param idCliente
	 * @param rut
	 * @param razonSocial
	 * @param direccion
	 * @param comuna
	 * @param cantEmpleados
	 * @param telefono
	 * @param usuario
	 */
	public Cliente(int idCliente, String rut, String razonSocial, String direccion,
			String comuna, int cantEmpleados, String telefono, Usuario usuario) {
		super();
		this.idCliente = idCliente;
		this.rut = rut;
		this.razonSocial = razonSocial;
		this.direccion = direccion;
		this.comuna = comuna;
		this.cantEmpleados = cantEmpleados;
		this.telefono = telefono;
		this.usuario = usuario;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getRut() {
		return rut;
	}

	public void setRut(String rut) {
		this.rut = rut;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getComuna() {
		return comuna;
	}

	public void setComuna(String comuna) {
		this.comuna = comuna;
	}

	public int getCantEmpleados() {
		return cantEmpleados;
	}

	public void setCantEmpleados(int cantEmpleados) {
		this.cantEmpleados = cantEmpleados;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", rut=" + rut + ", razonSocial=" + razonSocial + ", direccion="
				+ direccion + ", comuna=" + comuna + ", cantEmpleados=" + cantEmpleados + ", telefono=" + telefono
				+ ", usuario=" + usuario + "]";
	}
	
}