/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Administrativo
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.bubbles.finalspring.entity.Administrativo;

public interface IAdministrativoRepo extends JpaRepository<Administrativo, Integer> {

}
