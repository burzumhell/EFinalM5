/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Pago
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Pago;
import cl.bubbles.finalspring.repos.IPagoRepo;

@Service
public class PagoServiceImpl implements IPagoService {

	@Autowired
	IPagoRepo pr;
	
	@Override
	public List<Pago> listarPagos() {
		// TODO Auto-generated method stub
		return pr.findAll();
	}

	@Override
	public void crearPago(Pago p) {
		// TODO Auto-generated method stub
		pr.save(p);
	}

	@Override
	public void eliminarPago(int id) {
		// TODO Auto-generated method stub
		pr.deleteById(id);
	}
}
