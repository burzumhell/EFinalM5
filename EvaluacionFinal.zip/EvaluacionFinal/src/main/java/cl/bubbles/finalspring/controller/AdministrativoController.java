/**
 * @author The Bubbles
 * Controlador para la clase Administrativo
 */
package cl.bubbles.finalspring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Administrativo;
import cl.bubbles.finalspring.services.AdministrativoServiceImpl;

@Controller
public class AdministrativoController {

	@Autowired
	private AdministrativoServiceImpl as;
	
	@Autowired
	private AdministrativoServiceImpl ar;
	
	/**
	 * Método para acceder al formulario de registro de usuario tipo Administrativo
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_administrativo", method = RequestMethod.GET)
	public String crearAdministrativo() {
		
		return "crear_administrativo";
	}
	
	/**
	 * Método que recibe los datos de registro de usuario Administrativo
	 * @param a objeto Administrativo
	 * @return vista con listado de usuarios
	 */
	@RequestMapping(value = "/crear_administrativo", method = RequestMethod.POST)
	public ModelAndView crearAdministrativo(Administrativo a) {
		
		as.crearAdministrativo(a);
		
		return new ModelAndView("redirect:/listar_usuarios");
	}
	
	/**
	 * Método para edición de usuario tipo Administrativo
	 * @param a objeto Administrativo
	 * @return vista con listado de usuarios
	 */
	@RequestMapping(value = "/editar_administrativo", method = RequestMethod.POST)
	public ModelAndView editarUsuario(Administrativo a) {
		
		ar.update(a);
		
		return new ModelAndView("redirect:/listar_usuarios");
	}
}
