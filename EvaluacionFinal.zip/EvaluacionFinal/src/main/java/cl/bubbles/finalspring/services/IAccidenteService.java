/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Accidente
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Accidente;

public interface IAccidenteService {

	public List<Accidente> listarAccidentes();
	public void registrarAccidente(Accidente a);
	
}
