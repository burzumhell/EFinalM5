/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un asistente
 */
$(document).ready(function() {
	// Validate Plugin
	$('#formulario').validate({
		rules: {
			nombre: {
				required: true,
				rangelength: [5, 30]
			},
			edad: {
				required: true,
				min: 18,
				max: 65
			},
			correo: {
				required: true,
				email: true
			},
			telefono: {
				required: true,
				digits: true,
				minlength: 9,
				maxlength: 9
			}
		}
	});
});