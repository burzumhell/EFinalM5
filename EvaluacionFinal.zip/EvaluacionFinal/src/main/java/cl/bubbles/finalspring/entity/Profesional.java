/**
 * @author The Bubbles
 * Clase de objeto Profesional
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PROFESIONAL")
public class Profesional {

	@Id
	@Column(name = "idprofesional")
	private int idProfesional;
	
	@Column(name = "proexperiencia")
	private int aniosExperiencia;
	
	@Column(name = "prodepartamento")
	private String departamento;
	
	@Column(name = "protitulo")
	private String titulo;
	
	@Column(name = "profecha_ingreso")
	private String fechaIngreso;
	
	@ManyToOne
	@JoinColumn(name = "usuario_idusuario")
	private Usuario usuario;

	/**
	 * Constructor vacío
	 */
	public Profesional() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param idProfesional
	 * @param aniosExperiencia
	 * @param departamento
	 * @param titulo
	 * @param fechaIngreso
	 * @param usuario
	 */
	public Profesional(int idProfesional, int aniosExperiencia, String departamento, String titulo, String fechaIngreso,
			Usuario usuario) {
		super();
		this.idProfesional = idProfesional;
		this.aniosExperiencia = aniosExperiencia;
		this.departamento = departamento;
		this.titulo = titulo;
		this.fechaIngreso = fechaIngreso;
		this.usuario = usuario;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdProfesional() {
		return idProfesional;
	}

	public void setIdProfesional(int idProfesional) {
		this.idProfesional = idProfesional;
	}

	public int getAniosExperiencia() {
		return aniosExperiencia;
	}

	public void setAniosExperiencia(int aniosExperiencia) {
		this.aniosExperiencia = aniosExperiencia;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	@Override
	public String toString() {
		return "Profesional [idProfesional=" + idProfesional + ", aniosExperiencia=" + aniosExperiencia
				+ ", departamento=" + departamento + ", titulo=" + titulo + ", fechaIngreso=" + fechaIngreso
				+ ", usuario=" + usuario + "]";
	}
}