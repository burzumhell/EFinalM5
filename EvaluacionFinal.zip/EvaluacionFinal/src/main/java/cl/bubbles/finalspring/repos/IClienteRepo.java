/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Cliente
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.bubbles.finalspring.entity.Cliente;

public interface IClienteRepo extends JpaRepository<Cliente, Integer> {

}
