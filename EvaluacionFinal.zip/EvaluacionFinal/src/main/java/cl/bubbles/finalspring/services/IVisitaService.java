/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Visita
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Visita;

public interface IVisitaService {

	public List<Visita> listarVisitas();
	public void crearVisita(Visita v);
	
}
