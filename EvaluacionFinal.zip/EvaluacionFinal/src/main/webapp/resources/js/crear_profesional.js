/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un profesional
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			aniosExperiencia: {
                required: true,
                min: 1,
                max: 50
            },
            departamento: {
                required: true,
                rangelength: [5, 30]
            },
			titulo: {
                required: true,
                rangelength: [7, 50]
            },
			fechaIngreso: {
                required: true,
                rangelength: [5, 20]
            }
        }
    });
});