/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para una visitas
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			fecha: {
                required: true,
            },
            hora: {
                required: true,
            },
			lugar: {
                required: true,
                rangelength: [5, 30]
            },
            comentarios: {
                required: true,
                rangelength: [10, 250]
            },
        }
    });
});