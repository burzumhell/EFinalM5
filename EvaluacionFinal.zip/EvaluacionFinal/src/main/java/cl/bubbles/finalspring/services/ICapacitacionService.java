/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Capacitacion
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Capacitacion;

public interface ICapacitacionService {

	public List<Capacitacion> listarCapacitaciones();
	public void crearCapacitacion(Capacitacion c);
	public void eliminarCapacitacion(int id);
}
