----- USUARIO -----
CREATE TABLE usuario (
    idusuario           NUMBER(9),
    usurun              VARCHAR2(12),
    usunombre           VARCHAR2(20),
    usufecha_nacimiento VARCHAR2(20),
    password            VARCHAR2(100),
    usutipo             VARCHAR2(20),
    CONSTRAINT usuario_pk PRIMARY KEY (idusuario)
);

CREATE SEQUENCE USUARIO_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO usuario VALUES
(USUARIO_SEQ.nextval,'1-1','N1_admin','11/11/2001','$2a$10$o013LPyW0dv8YMFujIVltOAKKi0TgMn64R8J1642M4HfxMD8nsjKm','Administrativo');

INSERT INTO usuario VALUES
(USUARIO_SEQ.nextval,'2-2','N2_cli','11/11/2002','$2a$10$o013LPyW0dv8YMFujIVltOAKKi0TgMn64R8J1642M4HfxMD8nsjKm','Cliente');

INSERT INTO usuario VALUES
(USUARIO_SEQ.nextval,'3-3','N3_pro','11/11/2003','$2a$10$o013LPyW0dv8YMFujIVltOAKKi0TgMn64R8J1642M4HfxMD8nsjKm','Profesional');


----- ADMINISTRATIVO -----
CREATE TABLE administrativo (
    idadministrativo    NUMBER(9),
    admsuperior         VARCHAR2(50),
    admarea             VARCHAR2(20),
    admexperiencia      VARCHAR2(50),
    admfuncion          VARCHAR2(50),
    usuario_idusuario   NUMBER(9),
    CONSTRAINT administrativo_pk PRIMARY KEY (idadministrativo)
);

ALTER TABLE administrativo
ADD CONSTRAINT administrativo_usuario_fk FOREIGN KEY (usuario_idusuario)
REFERENCES usuario (idusuario);

INSERT INTO administrativo (idadministrativo,admsuperior,admarea,admexperiencia,admfuncion)
VALUES (1,'S1','A1','E1','F1');

INSERT INTO administrativo (idadministrativo,admsuperior,admarea,admexperiencia,admfuncion)
VALUES (2,'S2','A2','E2','F2');

INSERT INTO administrativo (idadministrativo,admsuperior,admarea,admexperiencia,admfuncion)
VALUES (3,'S3','A3','E3','F3');


----- CLIENTE -----
CREATE TABLE cliente (
    idcliente           NUMBER(9),
    rut_cliente         VARCHAR2(12),
    clirazon_social     VARCHAR2(30),
    clidireccion        VARCHAR2(100),
    clicomuna           VARCHAR2(30),
    cliempleados        NUMBER(3),
    clitelefono         VARCHAR2(15),
    usuario_idusuario   NUMBER(9),
    CONSTRAINT cliente_pk PRIMARY KEY (idcliente)
);

ALTER TABLE cliente
ADD CONSTRAINT cliente_usuario_fk FOREIGN KEY (usuario_idusuario)
REFERENCES usuario (idusuario);

INSERT INTO cliente (idcliente,rut_cliente,clirazon_social,clidireccion,clicomuna,cliempleados,clitelefono)
VALUES (1,'1-1','R1','D1','C1',10,'911111111');

INSERT INTO cliente (idcliente,rut_cliente,clirazon_social,clidireccion,clicomuna,cliempleados,clitelefono)
VALUES (2,'2-2','R2','D2','C2',20,'922222222');

INSERT INTO cliente (idcliente,rut_cliente,clirazon_social,clidireccion,clicomuna,cliempleados,clitelefono)
VALUES (3,'3-3','R3','D3','C3',30,'933333333');


----- PROFESIONAL -----
CREATE TABLE profesional (
    idprofesional       NUMBER(9),
    proexperiencia      NUMBER(2),
    prodepartamento     VARCHAR2(50),
    protitulo           VARCHAR2(50),
    profecha_ingreso    VARCHAR2(10),
    usuario_idusuario   NUMBER(9),
    CONSTRAINT profesional_pk PRIMARY KEY (idprofesional)
);

ALTER TABLE profesional
ADD CONSTRAINT profesional_usuario_fk FOREIGN KEY (usuario_idusuario)
REFERENCES usuario (idusuario);

INSERT INTO profesional (idprofesional,proexperiencia,prodepartamento,protitulo,profecha_ingreso)
VALUES (1,5,'Depto 1','T1','11/11/2001');

INSERT INTO profesional (idprofesional,proexperiencia,prodepartamento,protitulo,profecha_ingreso)
VALUES (2,10,'Depto 2','T2','11/11/2002');

INSERT INTO profesional (idprofesional,proexperiencia,prodepartamento,protitulo,profecha_ingreso)
VALUES (3,15,'Depto 3','T3','11/11/2003');

----- QUERY BORRADO -----
SELECT * FROM usuario;

DROP TABLE administrativo;

DROP TABLE cliente;

DROP TABLE profesional;

DROP TABLE usuario;

----------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------

----- PAGO -----
CREATE TABLE pago (
    idpago                  NUMBER(9),
    pagofecha               VARCHAR2(20),
    pagomonto               NUMBER(9),
    pagomes                 VARCHAR2(20),
    pagoanio                NUMBER(4),
    cliente                 VARCHAR2(20),
    cliente_idcliente       NUMBER(9),
    CONSTRAINT pagos_cliente_pk PRIMARY KEY (idpago)
);

ALTER TABLE pago
ADD CONSTRAINT pago_cliente_fk FOREIGN KEY (cliente_idcliente)
REFERENCES cliente (idcliente);

CREATE SEQUENCE PAGO_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO pago (idpago,pagofecha,pagomonto,pagomes,pagoanio,cliente) 
VALUES (PAGO_SEQ.nextval,'11/11/2001',100,'Enero',2011,'Cliente 1');

INSERT INTO pago (idpago,pagofecha,pagomonto,pagomes,pagoanio,cliente) 
VALUES (PAGO_SEQ.nextval,'11/11/2002',200,'Febrero',2012,'Cliente 2');

INSERT INTO pago (idpago,pagofecha,pagomonto,pagomes,pagoanio,cliente) 
VALUES (PAGO_SEQ.nextval,'11/11/2003',300,'Marzo',2013,'Cliente 3');

DROP TABLE pago;


----- CAPACITACION -----
CREATE TABLE capacitacion (
    idcapacitacion      NUMBER(9),
    caprut_cliente      VARCHAR2(12),
    capdia              VARCHAR2(10),
    caphora             VARCHAR2(5),
    caplugar            VARCHAR2(100),
    capduracion         NUMBER(4),
    capasistentes       NUMBER(4),
    cliente_idcliente   NUMBER(9),
    CONSTRAINT capacitacion_pk PRIMARY KEY (idcapacitacion)
);

ALTER TABLE capacitacion
ADD CONSTRAINT capacitacion_cliente_fk FOREIGN KEY (cliente_idcliente)
REFERENCES cliente (idcliente);

CREATE SEQUENCE CAPACITACION_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO capacitacion (idcapacitacion,caprut_cliente,capdia,caphora,caplugar,capduracion,capasistentes)
VALUES (CAPACITACION_SEQ.nextval,'1-1','Lunes','09:00','Santiago',90,10);

INSERT INTO capacitacion (idcapacitacion,caprut_cliente,capdia,caphora,caplugar,capduracion,capasistentes)
VALUES (CAPACITACION_SEQ.nextval,'2-2','Miércoles','10:00','Viña del Mar',60,20);

INSERT INTO capacitacion (idcapacitacion,caprut_cliente,capdia,caphora,caplugar,capduracion,capasistentes)
VALUES (CAPACITACION_SEQ.nextval,'3-3','Viernes','11:00','Batuco',90,30);

DROP TABLE capacitacion;


----- ASISTENTE -----
CREATE TABLE asistente (
    idasistente                 NUMBER(9),
    asisnombre                  VARCHAR2(100),
    asisedad                    NUMBER(3),
    asiscorreo                  VARCHAR2(50),
    asistelefono                VARCHAR2(15),
    capacitacion_idcapacitacion NUMBER(9),
    CONSTRAINT asistente_pk PRIMARY KEY (idasistente)
);

ALTER TABLE asistente
ADD CONSTRAINT asistente_capacitacion_fk FOREIGN KEY (capacitacion_idcapacitacion)
REFERENCES capacitacion (idcapacitacion);

CREATE SEQUENCE ASISTENTE_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO asistente (idasistente,asisnombre,asisedad,asiscorreo,asistelefono)
VALUES (ASISTENTE_SEQ.nextval,'Nombre 1',20,'correo_1@gmail.com','911111111');

INSERT INTO asistente (idasistente,asisnombre,asisedad,asiscorreo,asistelefono)
VALUES (ASISTENTE_SEQ.nextval,'Nombre 2',30,'correo_2@gmail.com','922222222');

INSERT INTO asistente (idasistente,asisnombre,asisedad,asiscorreo,asistelefono)
VALUES (ASISTENTE_SEQ.nextval,'Nombre 3',30,'correo_3@gmail.com','933333333');

DROP TABLE asistente;


----- VISITA -----
CREATE TABLE visita (
    idvisita             NUMBER(9),
    visfecha             VARCHAR2(10),
    vishora              VARCHAR2(5),
    vislugar             VARCHAR2(50),
    viscomentarios       VARCHAR2(250),
    viscliente           VARCHAR2(50),
    cliente_idcliente    NUMBER(9),
    CONSTRAINT visita_pk PRIMARY KEY (idvisita)
);

ALTER TABLE visita
ADD CONSTRAINT visita_cliente_fk FOREIGN KEY (cliente_idcliente)
REFERENCES cliente (idcliente);

CREATE SEQUENCE VISITA_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO visita (idvisita,visfecha,vishora,vislugar,viscomentarios)
VALUES(VISITA_SEQ.nextval,'11/11/2001','09:00','Santiago','Comentarios...');

INSERT INTO visita (idvisita,visfecha,vishora,vislugar,viscomentarios)
VALUES(VISITA_SEQ.nextval,'11/11/2002','10:00','Santiago','Comentarios...');

INSERT INTO visita (idvisita,visfecha,vishora,vislugar,viscomentarios)
VALUES(VISITA_SEQ.nextval,'11/11/2003','11:00','Santiago','Comentarios...');

DROP TABLE visita;


----- CHEQUEO -----
CREATE TABLE chequeo (
    idchequeo       NUMBER(9),
    cheqnombre      VARCHAR2(50),
    cheqcliente     VARCHAR2(50),
    cheqestado      VARCHAR2(20),
    cheqobservacion VARCHAR2(250),
    visita_idvisita NUMBER(9),
    CONSTRAINT chequeo_pk PRIMARY KEY (idchequeo)
);

ALTER TABLE chequeo
ADD CONSTRAINT chequeo_visita_fk FOREIGN KEY (visita_idvisita)
REFERENCES visita (idvisita);

CREATE SEQUENCE CHEQUEO_SEQ INCREMENT BY 1 MAXVALUE 999 MINVALUE 1 NOCACHE ORDER;

INSERT INTO chequeo (idchequeo,cheqnombre,cheqcliente,cheqestado,cheqobservacion)
VALUES(CHEQUEO_SEQ.nextval,'Chequeo 1','Cliente 1','Cumple','Observaciones...');

INSERT INTO chequeo (idchequeo,cheqnombre,cheqcliente,cheqestado,cheqobservacion)
VALUES(CHEQUEO_SEQ.nextval,'Chequeo 2','Cliente 2','No Cumple','Observaciones...');

INSERT INTO chequeo (idchequeo,cheqnombre,cheqcliente,cheqestado,cheqobservacion)
VALUES(CHEQUEO_SEQ.nextval,'Chequeo 3','Cliente 3','Con Observaciones','Observaciones...');

DROP TABLE chequeo;








