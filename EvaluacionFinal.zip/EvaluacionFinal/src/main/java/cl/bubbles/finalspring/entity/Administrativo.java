/**
 * @author The Bubbles
 * Clase de objeto Administrativo
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ADMINISTRATIVO")
public class Administrativo {
	
	@Id
	@Column(name = "idadministrativo")
	private int idAdmin;
	
	@Column(name = "admsuperior")
	private String nombreSuperior;
	
	@Column(name = "admarea")
	private String area;
	
	@Column(name = "admexperiencia")
	private String experienciaPrevia;
	
	@Column(name = "admfuncion")
	private String funcion;
	
	@ManyToOne
	@JoinColumn(name = "usuario_idusuario")
	private Usuario usuario;
	
	/**
	 * Constructor vacío
	 */
	public Administrativo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Constructor con parámetros
	 * @param idAdmin
	 * @param nombreSuperior
	 * @param area
	 * @param experienciaPrevia
	 * @param funcion
	 * @param usuario
	 */
	public Administrativo(int idAdmin, String nombreSuperior, String area,
			String experienciaPrevia, String funcion, Usuario usuario) {
		super();
		this.idAdmin = idAdmin;
		this.nombreSuperior = nombreSuperior;
		this.area = area;
		this.experienciaPrevia = experienciaPrevia;
		this.funcion = funcion;
		this.usuario = usuario;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdAdmin() {
		return idAdmin;
	}

	public void setIdAdmin(int idAdmin) {
		this.idAdmin = idAdmin;
	}

	public String getNombreSuperior() {
		return nombreSuperior;
	}

	public void setNombreSuperior(String nombreSuperior) {
		this.nombreSuperior = nombreSuperior;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getExperienciaPrevia() {
		return experienciaPrevia;
	}

	public void setExperienciaPrevia(String experienciaPrevia) {
		this.experienciaPrevia = experienciaPrevia;
	}

	public String getFuncion() {
		return funcion;
	}

	public void setFuncion(String funcion) {
		this.funcion = funcion;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	@Override
	public String toString() {
		return "Administrativo [idAdmin=" + idAdmin + ", nombreSuperior=" + nombreSuperior + ", area=" + area
				+ ", experienciaPrevia=" + experienciaPrevia + ", funcion=" + funcion + ", usuario=" + usuario + "]";
	}
}