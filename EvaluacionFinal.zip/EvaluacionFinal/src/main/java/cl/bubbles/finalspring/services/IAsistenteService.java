/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Asistente
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Asistente;

public interface IAsistenteService {
	
	public List<Asistente> listarAsistentes();
	public void agregarAsistente(Asistente a);
	public void eliminarAsistente(int id);
}
