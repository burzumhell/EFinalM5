/**
 * @author The Bubbles
 * Clase de objeto Chequeo
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CHEQUEO")
public class Chequeo {

	@Id
	@Column(name = "idchequeo")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "chequeo_seq")
	@SequenceGenerator(name = "chequeo_seq", allocationSize = 1)
	private int idChequeo;
	
	@Column(name = "cheqnombre")
	private String nombre;
	
	@Column(name = "cheqcliente")
	private String cliente;
	
	@Column(name = "cheqestado")
	private String estado;
	
	@Column(name = "cheqobservacion")
	private String observacion;
	
	@ManyToOne
	@JoinColumn(name = "visita_idvisita")
	private Visita visita;

	/**
	 * Constructor vacío
	 */
	public Chequeo() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param idChequeo
	 * @param nombre
	 * @param cliente
	 * @param estado
	 * @param observacion
	 * @param visita
	 */
	public Chequeo(int idChequeo, String nombre, String cliente, String estado,
			String observacion, Visita visita) {
		super();
		this.idChequeo = idChequeo;
		this.nombre = nombre;
		this.cliente = cliente;
		this.estado = estado;
		this.observacion = observacion;
		this.visita = visita;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdChequeo() {
		return idChequeo;
	}

	public void setIdChequeo(int idChequeo) {
		this.idChequeo = idChequeo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	public Visita getVisita() {
		return visita;
	}

	public void setVisita(Visita visita) {
		this.visita = visita;
	}

	@Override
	public String toString() {
		return "Chequeo [idChequeo=" + idChequeo + ", nombre=" + nombre + ", cliente=" + cliente + ", estado=" + estado
				+ ", observacion=" + observacion + ", visita=" + visita + "]";
	}
}
