/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un pago
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			fecha: {
                required: true
            },
            monto: {
                required: true,
                min: 10000,
                max: 99999999
            },
			mes: {
                required: true
            },
			anio: {
                required: true
            },
            nombreCliente: {
				required: true,
				rangelength: [3, 20]
			}
        }
    });
});