/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Profesional
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.bubbles.finalspring.entity.Profesional;

public interface IProfesionalRepo extends JpaRepository<Profesional, Integer> {

}
