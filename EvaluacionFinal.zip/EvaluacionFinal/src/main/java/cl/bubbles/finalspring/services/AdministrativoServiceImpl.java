/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Administrativo
 */
package cl.bubbles.finalspring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Administrativo;
import cl.bubbles.finalspring.repos.IAdministrativoRepo;

@Service
public class AdministrativoServiceImpl implements IAdministrativoService {

	@Autowired
	IAdministrativoRepo ar;
	
	@Override
	public Administrativo readOne(int id) {
		// TODO Auto-generated method stub
		return ar.findById(id).get();
	}

	@Override
	public void crearAdministrativo(Administrativo a) {
		// TODO Auto-generated method stub
		ar.save(a);
	}

	@Override
	public void update(Administrativo a) {
		// TODO Auto-generated method stub
		ar.save(a);
	}
}
