/**
 * @author The Bubbles
 * Controlador para la clase Asistente
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Asistente;
import cl.bubbles.finalspring.services.AsistenteServiceImpl;

@Controller
public class AsistenteController {
	
	@Autowired
	private AsistenteServiceImpl as;
	
	/**
	 * Método para obtener listado de asistentes
	 * @return lista de asistentes
	 */
	@RequestMapping(value = "/listar_asistentes", method = RequestMethod.GET)
	public ModelAndView listarAsistentes() {
		
		List<Asistente> lista = as.listarAsistentes();
		
		ModelAndView mv = new ModelAndView("listar_asistentes");
		mv.addObject("lista", lista);
		
		return mv;
		
	}
	
	/**
	 * Método para acceder al formulario de registro de un asistente
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/agregar_asistente", method = RequestMethod.GET)
	public String agregarAsistente() {
		
		return "agregar_asistente";
		
	}
	
	/**
	 * Método que recibe los datos de registro de un asistente
	 * @param a objeto Asistente
	 * @return vista de lista de asistentes
	 */
	@RequestMapping(value = "/agregar_asistente", method = RequestMethod.POST)
	public ModelAndView agregarAsistente(Asistente a) {
		
		as.agregarAsistente(a);
		
		return new ModelAndView("redirect:/listar_asistentes");
		
	}
	
	/**
	 * Método para eliminar un asistente del listado
	 * @param id del asistente
	 * @return vista de listado de asistentes
	 */
	@RequestMapping(value = "eliminar_asistente/{id}", method = RequestMethod.GET)
	public ModelAndView eliminarAsistente(@PathVariable("id") int id) {
		
		as.eliminarAsistente(id);
		
		return new ModelAndView("redirect:/listar_asistentes");
	}
	
}
