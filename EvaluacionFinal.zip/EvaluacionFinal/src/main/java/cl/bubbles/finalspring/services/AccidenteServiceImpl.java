/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Accidente
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Accidente;
import cl.bubbles.finalspring.repos.IAccidenteRepo;

@Service
public class AccidenteServiceImpl implements IAccidenteService {
	
	@Autowired
	IAccidenteRepo ar;

	@Override
	public List<Accidente> listarAccidentes() {
		
		return ar.findAll();
	}

	@Override
	public void registrarAccidente(Accidente a) {
		
		ar.save(a);
	}
}
