/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Visita
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Visita;
import cl.bubbles.finalspring.repos.IVisitaRepo;

@Service
public class VisitaServiceImpl implements IVisitaService{

	@Autowired
	IVisitaRepo vr;
	
	@Override
	public List<Visita> listarVisitas() {
		// TODO Auto-generated method stub
		return vr.findAll();
	}

	@Override
	public void crearVisita(Visita v) {
		// TODO Auto-generated method stub
		vr.save(v);
	}
}
