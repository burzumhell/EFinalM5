/**
 * @author The Bubbles
 * Controlador para la clase Usuario
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Administrativo;
import cl.bubbles.finalspring.entity.Cliente;
import cl.bubbles.finalspring.entity.Profesional;
import cl.bubbles.finalspring.entity.Usuario;
import cl.bubbles.finalspring.services.AdministrativoServiceImpl;
import cl.bubbles.finalspring.services.ClienteServiceImpl;
import cl.bubbles.finalspring.services.ProfesionalServiceImpl;
import cl.bubbles.finalspring.services.UsuarioServiceImpl;

@Controller
public class UsuarioController {

	@Autowired
	private UsuarioServiceImpl us;
	
	@Autowired
	private AdministrativoServiceImpl ar;
	
	@Autowired
	private ClienteServiceImpl cs;
	
	@Autowired
	private ProfesionalServiceImpl ps;
	
	/**
	 * Método para obtener listado de usuarios
	 * @return listado de usuarios
	 */
	@RequestMapping(value = "/listar_usuarios", method = RequestMethod.GET)
	public ModelAndView listarUsuarios() {
		
		List<Usuario> lista = us.listarUsuarios();
		
		ModelAndView mv = new ModelAndView("listar_usuarios");
		mv.addObject("lista", lista);
		
		return mv;
	}
	
	/**
	 * Método para acceder al formulario de ingreso de un usuario
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_usuario", method = RequestMethod.GET)
	public String crearUsuario() {
		
		return "crear_usuario";
	}
	
	/**
	 * Método que recibe los datos del usuario ingresado y crea un nuevo registro
	 * según el tipo o perfil de usuario seleccionado
	 * @return vista con formulario de ingreso de datos según tipo de usuario
	 */
	@RequestMapping(value = "/crear_usuario", method = RequestMethod.POST)
	public ModelAndView crearUsuario(Usuario u) {
		
		us.crearUsuario(u);
		
		if (u.getPerfil().equalsIgnoreCase("administrativo")) {
			
			return new ModelAndView("crear_administrativo", "u", u);
			
		} else if (u.getPerfil().equalsIgnoreCase("cliente")) {
			
			return new ModelAndView("crear_cliente", "u", u);
			
		} else {
			
			return new ModelAndView("crear_profesional", "u", u);
		}
	}
	
	/**
	 * Método para la edición y update de datos de usuarios
	 * @param perfil o tipo de usuario
	 * @param id de usuario
	 * @return vista con formualario para edición y update de datos
	 */
	@RequestMapping(value = "/editar_usuario/{perfil}/{id}", method = RequestMethod.GET)
	public ModelAndView editarUsuario(@PathVariable("perfil") String perfil,
			@PathVariable("id") int id) {
		
		System.out.println(perfil);
		
		if (perfil.equalsIgnoreCase("administrativo")) {
		
			return new ModelAndView("editar_administrativo", "a", ar.readOne(id));
			
		} else if (perfil.equalsIgnoreCase("cliente")) {
			
			return new ModelAndView("editar_cliente", "c", cs.readOne(id));
			
		} else {
			
			return new ModelAndView("editar_profesional", "p", ps.readOne(id));
		}
	}
	
	/**
	 * Método para eliminar un usuario del sistema
	 * @param id del usuario
	 * @return vista de listado de usuarios
	 */
	@RequestMapping(value = "eliminar_usuario/{id}", method = RequestMethod.GET)
	public ModelAndView eliminarUsuario(@PathVariable("id") int id) {
		
		us.eliminarUsuario(id);
		
		return new ModelAndView("redirect:/listar_usuarios");
	}
}
