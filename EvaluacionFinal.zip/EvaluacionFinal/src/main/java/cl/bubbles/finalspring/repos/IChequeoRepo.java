/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Chequeo
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.bubbles.finalspring.entity.Chequeo;

@Repository
public interface IChequeoRepo extends JpaRepository<Chequeo, Integer> {

}
