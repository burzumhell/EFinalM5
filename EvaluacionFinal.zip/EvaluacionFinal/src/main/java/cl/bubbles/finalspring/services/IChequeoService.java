/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Chequeo
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Chequeo;

public interface IChequeoService {

	public List<Chequeo> listarChequeos();
	
}
