/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Profesional
 */
package cl.bubbles.finalspring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Profesional;
import cl.bubbles.finalspring.repos.IProfesionalRepo;

@Service
public class ProfesionalServiceImpl implements IProfesionalService {

	@Autowired
	IProfesionalRepo pr;
	
	@Override
	public Profesional readOne(int id) {
		// TODO Auto-generated method stub
		return pr.findById(id).get();
	}

	@Override
	public void crearProfesional(Profesional p) {
		// TODO Auto-generated method stub
		pr.save(p);
	}

	@Override
	public void update(Profesional a) {
		// TODO Auto-generated method stub
		pr.save(a);
	}
}
