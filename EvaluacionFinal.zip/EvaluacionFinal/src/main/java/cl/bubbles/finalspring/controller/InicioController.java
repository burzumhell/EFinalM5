/**
 * @author The Bubbles
 * Controlador para identificar el tipo de usuario logeado
 */
package cl.bubbles.finalspring.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class InicioController {

	/**
	 * Método para obtener el tipo de usuario y establecer sus casos de uso en el menú
	 * @return vista de home y casos de uso en menú, según tipo de usuario logeado
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView inicio() {
		
		String user = SecurityContextHolder.getContextHolderStrategy().getContext().getAuthentication().getName();
		System.out.println("El usuario es: " + user);
		
		if (user.contains("cli")) {
			
			return new ModelAndView("index_cliente");
			
		} else if (user.contains("pro")) {
			
			return new ModelAndView("index_profesional");
			
		} else {
			
			return new ModelAndView("index_administrativo");
		}
	}
}
