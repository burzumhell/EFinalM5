/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Asistente
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.bubbles.finalspring.entity.Asistente;

@Repository
public interface IAsistenteRepo extends JpaRepository<Asistente, Integer> {

}
