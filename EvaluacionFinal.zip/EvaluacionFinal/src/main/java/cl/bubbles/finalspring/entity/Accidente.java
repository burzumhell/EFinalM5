/**
 * @author The Bubbles
 * Clase de objeto Accidente
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ACCIDENTE")
public class Accidente {
	
	@Id
	@Column(name = "idaccidente")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "accidente_seq")
	@SequenceGenerator(name = "accidente_seq", allocationSize = 1)
	private int id;
	
	@Column(name = "accifecha")
	private String fecha;
	
	@Column(name = "accihora")
	private String hora;
	
	@Column(name = "accilugar")
	private String lugar;
	
	@Column(name = "acciorigen")
	private String origen;
	
	@Column(name = "acciconsecuencias")
	private String consecuencias;

	/**
	 * Constructor vacío
	 */
	public Accidente() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Constructor con parámetros
	 * @param id
	 * @param fecha
	 * @param hora
	 * @param lugar
	 * @param origen
	 * @param consecuencias
	 */
	public Accidente(int id, String fecha, String hora, String lugar, String origen, String consecuencias) {
		super();
		this.id = id;
		this.fecha = fecha;
		this.hora = hora;
		this.lugar = lugar;
		this.origen = origen;
		this.consecuencias = consecuencias;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getConsecuencias() {
		return consecuencias;
	}

	public void setConsecuencias(String consecuencias) {
		this.consecuencias = consecuencias;
	}

	@Override
	public String toString() {
		return "Accidente [id=" + id + ", fecha=" + fecha + ", hora=" + hora + ", lugar=" + lugar + ", origen=" + origen
				+ ", consecuencias=" + consecuencias + "]";
	}

}
