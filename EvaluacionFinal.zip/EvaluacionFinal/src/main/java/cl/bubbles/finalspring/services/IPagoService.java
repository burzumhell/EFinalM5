/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Pago
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Pago;

public interface IPagoService {

	public List<Pago> listarPagos();
	public void crearPago(Pago p);
	public void eliminarPago(int id);
	
}
