/**
 * @author The Bubbles
 * Clase de objeto Usuario
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "USUARIO")
public class Usuario {

	@Id
	@Column(name = "idusuario")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "usuario_seq")
	@SequenceGenerator(name = "usuario_seq", allocationSize = 1)
	private int id;
	
	@Column(name = "usurun")
	private String run;
	
	@Column(name = "usunombre")
	private String nombre;
	
	@Column(name = "usufecha_nacimiento")
	private String fechaNacimiento;
	
	@Column(name="password")
	private String password;
	
	@Column(name = "usutipo")
	private String perfil;

	/**
	 * Constructor vacío
	 */
	public Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param id
	 * @param run
	 * @param nombre
	 * @param fechaNacimiento
	 * @param password
	 * @param perfil
	 */
	public Usuario(int id, String run, String nombre, String fechaNacimiento, String password, String perfil) {
		super();
		this.id = id;
		this.run = run;
		this.nombre = nombre;
		this.fechaNacimiento = fechaNacimiento;
		this.password = password;
		this.perfil = perfil;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRun() {
		return run;
	}

	public void setRun(String run) {
		this.run = run;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPerfil() {
		return perfil;
	}

	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", run=" + run + ", nombre=" + nombre + ", fechaNacimiento=" + fechaNacimiento
				+ ", password=" + password + ", perfil=" + perfil + "]";
	}

}