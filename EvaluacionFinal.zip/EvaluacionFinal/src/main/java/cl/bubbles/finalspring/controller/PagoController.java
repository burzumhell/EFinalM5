/**
 * @author The Bubbles
 * Controlador para la clase Pago
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Pago;
import cl.bubbles.finalspring.services.PagoServiceImpl;

@Controller
public class PagoController {

	@Autowired
	private PagoServiceImpl ps;
	
	/**
	 * Método para obtener listado de pagos
	 * @return listado de pagos
	 */
	@RequestMapping(value = "listar_pagos", method = RequestMethod.GET)
	public ModelAndView listarPagos() {
		
		List<Pago> lista = ps.listarPagos();
		
		ModelAndView mv = new ModelAndView("listar_pagos");
		mv.addObject("lista", lista);
		
		return mv;
	}
	
	/**
	 * Método para acceder al formulario de registro de un pago
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_pago", method = RequestMethod.GET)
	public String crearPago() {
		
		return "crear_pago";
	}

	/**
	 * Método que recibe los datos del paggo ingresado y crea un nuevo registro
	 * @param p objeto Pago
	 * @return vista de listado de pagos
	 */
	@RequestMapping(value = "crear_pago", method = RequestMethod.POST)
	public ModelAndView crearPago(Pago p) {
		
		ps.crearPago(p);
		
		return new ModelAndView("redirect:/listar_pagos");
	}
	
	/**
	 * Método para eliminar un usuario del sistema
	 * @param id del usuario
	 * @return vista de listado de usuarios
	 */
	@RequestMapping(value = "eliminar_pago/{id}", method = RequestMethod.GET)
	public ModelAndView eliminarPago(@PathVariable("id") int id) {
		
		ps.eliminarPago(id);
		
		return new ModelAndView("redirect:/listar_pagos");
	}
}
