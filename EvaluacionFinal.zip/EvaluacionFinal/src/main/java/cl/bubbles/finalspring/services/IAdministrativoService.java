/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Administrativo
 */
package cl.bubbles.finalspring.services;

import cl.bubbles.finalspring.entity.Administrativo;

public interface IAdministrativoService {
	
	public Administrativo readOne(int id);
	public void crearAdministrativo(Administrativo a);
	public void update(Administrativo a);
	
}
