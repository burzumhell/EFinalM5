/**
 * @author The Bubbles
 * Clase de objeto Visita
 */
package cl.bubbles.finalspring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "VISITA")
public class Visita {
	
	@Id
	@Column(name = "idvisita")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "visita_seq")
	@SequenceGenerator(name = "visita_seq", allocationSize = 1)
	private int idVisita;
	
	@Column(name = "visfecha")
	private String fecha;
	
	@Column(name = "vishora")
	private String hora;
	
	@Column(name = "vislugar")
	private String lugar;
	
	@Column(name = "viscliente")
	private String visitaCliente;
	
	@Column(name = "viscomentarios")
	private String comentarios;
	
	@ManyToOne
	@JoinColumn(name = "cliente_idcliente")
	private Cliente cliente;
	
	/**
	 * Constructor vacío
	 */
	public Visita() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Constructor con parámetros
	 * @param idVisita
	 * @param fecha
	 * @param hora
	 * @param lugar
	 * @param visitaCliente
	 * @param comentarios
	 * @param cliente
	 */
	public Visita(int idVisita, String fecha, String hora, String lugar, String visitaCliente, String comentarios,
			Cliente cliente) {
		super();
		this.idVisita = idVisita;
		this.fecha = fecha;
		this.hora = hora;
		this.lugar = lugar;
		this.visitaCliente = visitaCliente;
		this.comentarios = comentarios;
		this.cliente = cliente;
	}

	/**
	 * Getters and Setters
	 * @return
	 */
	public int getIdVisita() {
		return idVisita;
	}

	public void setIdVisita(int idVisita) {
		this.idVisita = idVisita;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getLugar() {
		return lugar;
	}

	public void setLugar(String lugar) {
		this.lugar = lugar;
	}

	public String getVisitaCliente() {
		return visitaCliente;
	}

	public void setVisitaCliente(String visitaCliente) {
		this.visitaCliente = visitaCliente;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	@Override
	public String toString() {
		return "Visita [idVisita=" + idVisita + ", fecha=" + fecha + ", hora=" + hora + ", lugar=" + lugar
				+ ", visitaCliente=" + visitaCliente + ", comentarios=" + comentarios + ", cliente=" + cliente + "]";
	}
}