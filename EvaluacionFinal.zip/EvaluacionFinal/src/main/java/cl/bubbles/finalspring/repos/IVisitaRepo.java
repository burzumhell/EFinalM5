/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Visita
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.bubbles.finalspring.entity.Visita;

public interface IVisitaRepo extends JpaRepository<Visita, Integer> {

}
