/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Capacitación
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.bubbles.finalspring.entity.Capacitacion;

@Repository
public interface ICapacitacionRepo extends JpaRepository<Capacitacion, Integer> {

}
