/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Usuario
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Administrativo;
import cl.bubbles.finalspring.entity.Usuario;
import cl.bubbles.finalspring.repos.IAdministrativoRepo;
import cl.bubbles.finalspring.repos.IUsuarioRepo;

@Service
public class UsuarioServiceImpl implements IUsuarioService {

	@Autowired
	IUsuarioRepo ur;
	
	@Override
	public List<Usuario> listarUsuarios() {
		// TODO Auto-generated method stub
		return ur.findAll();
	}

	@Override
	public void crearUsuario(Usuario u) {
		// TODO Auto-generated method stub
		ur.save(u);
	}

	@Override
	public Usuario readOne(int id) {
		// TODO Auto-generated method stub
		return ur.findById(id).get();
	}

	@Override
	public void eliminarUsuario(int id) {
		// TODO Auto-generated method stub
		ur.deleteById(id);
	}
}
