/**
 * @author The Bubbles
 * Controlador para la clase Accidente
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Accidente;
import cl.bubbles.finalspring.services.AccidenteServiceImpl;

@Controller
public class AccidenteController {

	@Autowired
	private AccidenteServiceImpl as;
	
	/**
	 * Método para obtener listado de accidentes
	 * @return listado de accidentes
	 */
	@RequestMapping(value = "/listar_accidentes", method = RequestMethod.GET)
	public ModelAndView listarAccidentes() {
		
		List<Accidente> lista = as.listarAccidentes();
		
		ModelAndView mv = new ModelAndView("listar_accidentes");
		mv.addObject("lista", lista);
		
		return mv;
		
	}
	
	/**
	 * Método para acceder al formulario de registro de un accidente
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/registrar_accidente", method = RequestMethod.GET)
	public String registrarAccidente() {
		
		return "registrar_accidente";
		
	}
	
	/**
	 * Método que recibe los datos del accidente ingresado y crea un nuevo registro
	 * @param a objeto Accidente
	 * @return vista de listado de accidentes
	 */
	@RequestMapping(value = "/registrar_accidente", method = RequestMethod.POST)
	public ModelAndView registrarAccidente(Accidente a) {
		
		as.registrarAccidente(a);
		
		return new ModelAndView("redirect:/listar_accidentes");
		
	}
}
