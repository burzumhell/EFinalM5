/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Capacitacion
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Capacitacion;
import cl.bubbles.finalspring.repos.ICapacitacionRepo;

@Service
public class CapacitacionServiceImpl implements ICapacitacionService {

	@Autowired
	ICapacitacionRepo cr;
	
	@Override
	public List<Capacitacion> listarCapacitaciones() {
		
		return cr.findAll();
	}

	@Override
	public void crearCapacitacion(Capacitacion c) {
		
		cr.save(c);
	}

	@Override
	public void eliminarCapacitacion(int id) {
		// TODO Auto-generated method stub
		cr.deleteById(id);
	}
}
