/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para una capacitacion
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			rutCliente: {
                required: true,
                rangelength: [11, 12]
            },
            dia: {
                required: true,
            },
			hora: {
                required: true,
            },
            lugar: {
                required: true,
                rangelength: [5, 30]
            },
			duracion: {
                required: true,
                min: 15,
                max: 360
            },
			asistentes: {
                required: true,
                min: 5,
                max: 500
            }
        }
    });
});