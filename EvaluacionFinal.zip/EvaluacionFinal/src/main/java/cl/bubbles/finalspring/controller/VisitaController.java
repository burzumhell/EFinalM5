/**
 * @author The Bubbles
 * Controlador para la clase Visita
 */
package cl.bubbles.finalspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cl.bubbles.finalspring.entity.Visita;
import cl.bubbles.finalspring.services.VisitaServiceImpl;

@Controller
public class VisitaController {

	@Autowired
	private VisitaServiceImpl vs;
	
	/**
	 * Método para obtener listado de visitas
	 * @return lista de visitas
	 */
	@RequestMapping(value = "/listar_visitas", method = RequestMethod.GET)
	public ModelAndView listarVisitas() {
		
		List<Visita> lista = vs.listarVisitas();
		
		ModelAndView mv = new ModelAndView("listar_visitas");
		mv.addObject("lista", lista);
		
		return mv;
	}
	
	/**
	 * Método para acceder al formulario de registro de una visita
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/crear_visita", method = RequestMethod.GET)
	public String crearVisita() {
	
		return "crear_visita";
	}
	
	/**
	 * Método que recibe los datos de la visita ingresada y crea un nuevo registro
	 * @param c objeto
	 * @return
	 */
	@RequestMapping(value = "/crear_visita", method = RequestMethod.POST)
	public ModelAndView crearVisita(Visita v) {
		
		vs.crearVisita(v);
		
		return new ModelAndView("redirect:/listar_visitas");
	}
}
