/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un usuario
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			run: {
                required: true,
                rangelength: [11, 12]
            },
            nombre: {
                required: true,
                rangelength: [3, 30]
            },
			fechaNacimiento: {
                required: true
            },
			perfil: {
                required: true
            },
        }
    });
});