/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Usuario
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.bubbles.finalspring.entity.Usuario;

public interface IUsuarioRepo extends JpaRepository<Usuario, Integer> {

}
