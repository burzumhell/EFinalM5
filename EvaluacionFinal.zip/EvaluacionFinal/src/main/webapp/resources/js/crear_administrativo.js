/**
 * @author The Bubbles
 * Validación de formulario de ingreso de datos para un administrativo
 */
$(document).ready(function () {
    // Validate Plugin
    $('#formulario').validate({
        rules: {
			nombreSuperior: {
                required: true,
                rangelength: [5, 30]
            },
            area: {
                required: true,
                rangelength: [5, 30]
            },
			experienciaPrevia: {
                required: true,
                rangelength: [10, 50]
            },
			funcion: {
                required: true,
                rangelength: [5, 15]
            },
        }
    });
});