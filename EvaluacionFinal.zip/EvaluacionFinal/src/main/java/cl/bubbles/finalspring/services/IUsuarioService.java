/**
 * @author The Bubbles
 * Interface con métodos CRUD de clase Usuario
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import cl.bubbles.finalspring.entity.Administrativo;
import cl.bubbles.finalspring.entity.Usuario;

public interface IUsuarioService {
	
	public List<Usuario> listarUsuarios();
	public void crearUsuario(Usuario u);
	public Usuario readOne(int id);
	public void eliminarUsuario(int id);

}
