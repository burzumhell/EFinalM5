/**
 * @author The Bubbles
 * Controlador para la clase Contacto
 */
package cl.bubbles.finalspring.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ContactoController {
	
	private static final Logger logInfo = LoggerFactory.getLogger(ContactoController.class);

	/**
	 * Método para acceder al formulario de contacto
	 * @return vista con formulario de ingreso de datos
	 */
	@RequestMapping(value = "/contacto", method = RequestMethod.GET)
	public String contacto() {
		
		return "contacto";
	}
	
	/**
	 * Método que recibe los datos del mensaje ingresado
	 * @param nombre
	 * @param correo
	 * @param telefono
	 * @param mensaje
	 * @return vista de confirmación
	 */
	@RequestMapping(value = "/contacto", method = RequestMethod.POST)
	public ModelAndView contactoMensaje(@RequestParam("nombre") String nombre,
			@RequestParam("correo") String correo, @RequestParam("telefono") String telefono,
			@RequestParam("mensaje") String mensaje) {
			
		logInfo.info("Nombre: " + nombre);
		logInfo.info("Correo: " + correo);
		logInfo.info("Teléfono: " + telefono);
		logInfo.info("Mensaje: " + mensaje);
			
		return new ModelAndView("mensaje");
	}
}
