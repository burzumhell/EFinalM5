/**
 * @author The Bubbles
 * Validación de rut capacitacion
 */
$("input#rutCliente")
	.rut({ formatOn: 'keyup', validateOn: 'keyup' })
	.on('rutInvalido', function() {
		$(this).parents(".validaRut").addClass("error2")
		$("#label").text(" - RUT INVÁLIDO")
	})
	.on('rutValido', function() {
		$(this).parents(".validaRut").removeClass("error2")
		$("#label").text("")
	});