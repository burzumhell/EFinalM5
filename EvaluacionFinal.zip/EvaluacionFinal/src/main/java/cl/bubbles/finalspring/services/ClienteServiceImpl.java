/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Cliente
 */
package cl.bubbles.finalspring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Cliente;
import cl.bubbles.finalspring.repos.IClienteRepo;

@Service
public class ClienteServiceImpl implements IClienteService {

	@Autowired
	IClienteRepo cr;
	
	@Override
	public Cliente readOne(int id) {
		// TODO Auto-generated method stub
		return cr.findById(id).get();
	}

	@Override
	public void crearCliente(Cliente c) {
		// TODO Auto-generated method stub
		cr.save(c);
	}

	@Override
	public void update(Cliente c) {
		// TODO Auto-generated method stub
		cr.save(c);
	}
}
