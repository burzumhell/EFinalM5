/**
 * @author The Bubbles
 * Interface repositorio JPA de clase Accidente
 */
package cl.bubbles.finalspring.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.bubbles.finalspring.entity.Accidente;

@Repository
public interface IAccidenteRepo extends JpaRepository<Accidente, Integer> {

}
