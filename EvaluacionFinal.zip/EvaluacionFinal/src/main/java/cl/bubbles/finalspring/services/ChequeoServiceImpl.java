/**
 * @author The Bubbles
 * Clase de implementación métodos CRUD de interface Chequeo
 */
package cl.bubbles.finalspring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.bubbles.finalspring.entity.Chequeo;
import cl.bubbles.finalspring.repos.IChequeoRepo;

@Service
public class ChequeoServiceImpl implements IChequeoService {

	@Autowired
	IChequeoRepo chr;
	
	@Override
	public List<Chequeo> listarChequeos() {
		// TODO Auto-generated method stub
		return chr.findAll();
	}
}
